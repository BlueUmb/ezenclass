package kr.co.ezenac.variable;

public class VariableTest {

	public static void main(String[] args) {
		int age, count;
		age = 10;
		
		int level = 10000;
		System.out.println(age);
		System.out.println(level);

		System.out.println(age + level);
		

	}

}
