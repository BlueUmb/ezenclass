package kr.co.ezenac.variable02;

public class VariableTest {

	public static void main(String[] args) {
		byte b1 = 127;
		System.out.println(b1);
		
		//int num = 12345678900;
		//long num = 12345678900;
		long num = 12345678900L;
	}
}
