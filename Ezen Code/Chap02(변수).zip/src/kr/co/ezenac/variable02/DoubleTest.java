package kr.co.ezenac.variable02;

public class DoubleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 double dnum = 3.14;
		 float fnum = 3.14F;
		 
		 System.out.println(dnum);
		 System.out.println(fnum);
	}

}
